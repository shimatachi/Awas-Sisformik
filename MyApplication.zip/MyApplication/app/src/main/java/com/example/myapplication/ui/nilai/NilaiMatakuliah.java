package com.example.myapplication.ui.nilai;

public class NilaiMatakuliah {
    private String namamatkul;
    private String sks;
    private String totalnilai;

    public NilaiMatakuliah(String namamatkul, String sks, String totalnilai) {
        this.namamatkul = namamatkul;
        this.sks = sks;
        this.totalnilai = totalnilai;
    }

    public String getNamamatkul() {
        return namamatkul;
    }

    public void setNamamatkul(String namamatkul) {
        this.namamatkul = namamatkul;
    }

    public String getSks() {
        return sks;
    }

    public void setSks(String sks) {this.sks= sks; }

    public String getTotalnilai() {
        return totalnilai;
    }

    public void setTotalnilai(String totalnilai) {
        this.totalnilai = totalnilai;
    }


}