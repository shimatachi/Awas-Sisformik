package com.example.myapplication.ui.nilai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class Nilai extends AppCompatActivity {
    private static final String TAG = "Nilai";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nilai);

        setTitle("Nilai");

        Log.d(TAG, "onCreate: Started");
        ListView mListView = (ListView) findViewById(R.id.listview);

        NilaiMatakuliah Manajemen_Proyek_Sistem_Informasi =  new NilaiMatakuliah("Manajemen Proyek SIstem Informasi","2 SKS","A");
        NilaiMatakuliah Pengembangan_Aplikasi_Mobile =  new NilaiMatakuliah("Pengembangan Aplikasi Mobile","2 SKS","A");
        NilaiMatakuliah Metodologi_Penelitian =  new NilaiMatakuliah("Metodologi Penelitian","2 SKS","A");
        NilaiMatakuliah Etika_Profesi =  new NilaiMatakuliah("Etika Profesi","2 SKS","A");
        NilaiMatakuliah Mobile_Game_Developer =  new NilaiMatakuliah("Mobile Game Developer","2 SKS","A");
        NilaiMatakuliah Evaluasi_dan_Audit_SI =  new NilaiMatakuliah("Evaluasi & Audit SI","2 SKS","A");
        NilaiMatakuliah Sistem_Cerdas =  new NilaiMatakuliah("Sistem Cerdas","2 SKS","A");
        NilaiMatakuliah Pemrograman_Web =  new NilaiMatakuliah("Pemrograman Web","2 SKS","A");

        ArrayList<NilaiMatakuliah> nilaimatakuliahList = new ArrayList<>();
        nilaimatakuliahList.add(Manajemen_Proyek_Sistem_Informasi);
        nilaimatakuliahList.add(Pengembangan_Aplikasi_Mobile);
        nilaimatakuliahList.add(Metodologi_Penelitian);
        nilaimatakuliahList.add(Etika_Profesi);
        nilaimatakuliahList.add(Mobile_Game_Developer);
        nilaimatakuliahList.add(Evaluasi_dan_Audit_SI);
        nilaimatakuliahList.add(Sistem_Cerdas);
        nilaimatakuliahList.add(Pemrograman_Web);

        NilaiMataKuliahListAdapter adapter = new NilaiMataKuliahListAdapter(this, R.layout.adapter_view_layout, nilaimatakuliahList);
        mListView.setAdapter(adapter);


    }
}