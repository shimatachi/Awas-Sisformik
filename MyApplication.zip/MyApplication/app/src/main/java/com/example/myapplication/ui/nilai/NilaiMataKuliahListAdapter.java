package com.example.myapplication.ui.nilai;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.ArrayList;

public class NilaiMataKuliahListAdapter extends ArrayAdapter<NilaiMatakuliah> {
    private static final String TAG = "NilaiMataKuliahListAdapter";

    private final Context mMontext;
    int mResource;

    /**
     *
     * @param context
     * @param resource
     * @param objects
     */

    public NilaiMataKuliahListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<NilaiMatakuliah> objects) {
        super(context, resource, objects);
        this.mMontext = context;
        this.mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String namamatkul = getItem(position).getNamamatkul();
        String sks = getItem(position).getSks();
        String totalnilai = getItem(position).getTotalnilai();

        LayoutInflater inflater = LayoutInflater.from(mMontext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView tvNama = (TextView) convertView.findViewById(R.id.textView1);
        TextView tvSks = (TextView) convertView.findViewById(R.id.textView2);
        TextView tvTotalnilai = (TextView) convertView.findViewById(R.id.textView3);
        tvNama.setText(namamatkul);
        tvSks.setText(sks);
        tvTotalnilai.setText(totalnilai);

        return convertView;
    }
}
